using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using magdalagaApp.Models;

namespace magdalagaApp.Controllers;

public class HelloWorldController : Controller
{
    public IActionResult personal(){
        ViewData["age"] = 65;
        return View();
    }
    public IActionResult educ(){
        return View();
    }
    public IActionResult dream(){
        return View();
    }
    public IActionResult SiomaiRice(){
        return View();
    }
}
