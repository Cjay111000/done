﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using magdalagaApp.Models;

namespace magdalagaApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    { 
    //     person p1 = new person();
    //     p1.ID = 60000;
    //     p1.FullName = "Beat";
    //     p1.Brand = "Honda";
    
    //    person p2 = new person();
    //     p2.ID = 150000;
    //     p2.FullName = "Nmax";
    //     p2.Brand = "Yamaha";

    //     person p3 = new person();
    //     p3.ID = 50000;
    //     p3.FullName = "Raider";
    //     p3.Brand = "Kawasaki";

    //     List<person> cjay = new List<person>();

    //     cjay.Add(p1);
    //     cjay.Add(p2);
    //     cjay.Add(p3);

        return View();
    }
        

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
