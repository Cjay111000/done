using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using magdalagaApp.Models;

namespace magdalagaApp.Controllers;

public class SiomaiRice : Controller
{
    public IActionResult Index(){
        return View();
    }
}
