using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using magdalagaApp.Models;

namespace magdalagaApp.Controllers;

public class SiomaiController : Controller
{
    public IActionResult Index(){
        return View();
    }
    public IActionResult SiomaiRice(){
        return View();
    }
}
